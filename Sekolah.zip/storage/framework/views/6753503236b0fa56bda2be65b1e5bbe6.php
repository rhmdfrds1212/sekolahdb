<?php $__env->startSection('title','TAMBAH KELAS'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h3 class="text-center">Form Tambah Kelas</h3>
      <!-- Vertical Form -->
      <form class="row g-3" method="POST" action="<?php echo e(route('kelas.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="col-12 ">
            <label for="jurusan_id" class="form-label">Jurusan</label>
            <select class="form-control" id="jurusan_id" name="jurusan_id" placeholder="Masukan Jurusan">
                <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($items['id']); ?>">
                        <?php echo e($items['singkatan']); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-12 ">
            <label for="no" class="form-label">Tingkatan Kelas</label>
            <select class="form-control" id="no" name="no" placeholder="Masukan Tingkatan Kelas">
                <option value="X">10</option>
                <option value="XI">11</option>
                <option value="XII">12</option>
            </select>
        </div>
        <div class="col-12 ">
            <label for="nama" class="form-label">Nama Kelas</label>
            <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukan Nama Kelas">
        </div>
        <div class="col-12 ">
            <label for="wali" class="form-label">Wali Kelas</label>
            <input type="text" class="form-control" id="wali" name="wali" placeholder="Masukan Wali Kelas">
        </div>
        <div class="col-12 ">
            <label for="jumlah" class="form-label">Jumlah Siswa</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" placeholder="Masukan Jumlah Siswa">
        </div>
        <div class="col-12 ">
            <label for="motto" class="form-label">Motto Kelas</label>
            <input type="text" class="form-control" id="motto" name="motto" placeholder="Masukan Motto Kelas">
        </div>
        <div class="text-center">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <a href="<?php echo e(url('jurusan')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rpl\project-uas-si4b-supergaek\SekolahApp\resources\views/kelas/create.blade.php ENDPATH**/ ?>