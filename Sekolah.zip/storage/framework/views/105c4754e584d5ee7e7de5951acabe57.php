<?php $__env->startSection('title','TAMBAH GURU'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h3 class="text-center">Form Tambah Guru</h3>
      <!-- Vertical Form -->
      <form class="row g-3" method="POST" action="<?php echo e(route('guru.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="col-12 ">
            <label for="nuptk" class="form-label">NUPTK Guru</label>
            <input type="text" class="form-control" id="nuptk" name="nuptk" placeholder="Masukan NUPTK Guru">
        </div>
        <div class="col-12 ">
            <label for="nama" class="form-label">Nama Guru</label>
            <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukan Nama Guru">
        </div>
        <div class="col-12 ">
            <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
            <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" placeholder="Masukan Jenis Kelamin">
                <option value="Laki-Laki">Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
        </div>
        <div class="col-12 ">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Masukan Email Guru">
        </div>
        <div class="col-12 ">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Masukan Alamat Guru">
        </div>
        <div class="col-12 ">
            <label for="jurusan_id" class="form-label">Jurusan</label>
            <select class="form-control" id="jurusan_id" name="jurusan_id" placeholder="Masukan Jurusan">
                <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($items['id']); ?>">
                        <?php echo e($items['singkatan']); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-12 ">
            <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
            <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" placeholder="Masukan Tempat Lahir">
        </div>
        <div class="col-12 ">
            <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
            <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" placeholder="Masukan Tanggal Lahir">
        </div>
        <div class="col-12">
            <label for="url_guru">Foto</label>
            <input type="file" class="form-control" name="url_guru">
          </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(url('guru')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rpl\project-uas-si4b-supergaek\SekolahApp\resources\views/guru/create.blade.php ENDPATH**/ ?>