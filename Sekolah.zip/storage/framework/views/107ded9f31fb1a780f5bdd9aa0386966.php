<?php $__env->startSection('title','TAMBAH EKSTRAKULIKULER'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h3 class="text-center">Form Tambah EKSTRAKULIKULER</h3>
      <!-- Vertical Form -->
      <form class="row g-3" method="POST" action="<?php echo e(route('eskul.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="col-12 ">
          <label for="kode_eskul" class="form-label">Kode Eskul</label>
          <input type="text" class="form-control" id="kode_eskul" name="kode_eskul" placeholder="Masukan Kode Eskul">
        </div>
        <div class="col-12 ">
          <label for="nama" class="form-label">Nama Eskul</label>
          <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukan Nama Eskul">
        </div>
        <div class="col-12 ">
          <label for="pelatih" class="form-label">Pelatih Eskul</label>
          <input type="text" class="form-control" id="pelatih" name="pelatih" placeholder="Masukan Pelatih Eskul">
        </div>
        <div class="col-12 ">
          <label for="tanggal_resmi" class="form-label">Tanggal Resmi</label>
          <input type="date" class="form-control" id="tanggal_resmi" name="tanggal_resmi" placeholder="Masukan Tanggal Resmi">
        </div>
        <div class="text-center">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <a href="<?php echo e(url('eskul')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rpl\project-uas-si4b-supergaek\SekolahApp\resources\views/eskul/create.blade.php ENDPATH**/ ?>