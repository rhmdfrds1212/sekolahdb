<?php $__env->startSection('title','EDIT JURUSAN'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h3 class="text-center">From Edit Jurusan</h3>
      <!-- Vertical Form -->
      <form class="row g-3" method="POST" action="<?php echo e(route('jurusan.update', $jurusan['id'])); ?>">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="col-12 ">
          <label for="singkatan" class="form-label">Singkatan</label>
          <input type="text" class="form-control" id="singkatan" name="singkatan" value="<?php echo e(old('singkatan') ? old('singkatan'): $jurusan['singkatan']); ?>" placeholder="Masukan Singkatan Jurusan">
        </div>
        <div class="col-12 ">
          <label for="nama" class="form-label">Nama Jurusan</label>
          <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(old('nama') ? old('nama'): $jurusan['nama']); ?>" placeholder="Masukan Nama Jurusan">
        </div>
        <div class="col-12 ">
          <label for="pimpinan" class="form-label">Pimpinan Jurusan</label>
          <input type="text" class="form-control" id="pimpinan" name="pimpinan" value="<?php echo e(old('pimpinan') ? old('pimpinan'): $jurusan['pimpinan']); ?>" placeholder="Masukan Pimpinan Jurusan">
        </div>
        <div class="col-12 ">
          <label for="deskripsi" class="form-label">Deskripsi Jurusan</label>
          <input type="text" class="form-control" id="deskripsi" name="deskripsi" value="<?php echo e(old('deskripsi') ? old('deskripsi'): $jurusan['deskripsi']); ?>" placeholder="Masukan Deskripsi Jurusan">
        </div>
        <div class="text-center">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <a href="<?php echo e(url('jurusan')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rpl\project-uas-si4b-supergaek\SekolahApp\resources\views/jurusan/edit.blade.php ENDPATH**/ ?>