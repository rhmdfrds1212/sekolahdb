<?php $__env->startSection('title', 'SISWA'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-center">SISWA</h1>
<a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-primary col-lg-12 mb-3">Tambah Siswa</a>
<div class="table-responsive pt-3">
  <table class="table table-bordered border-primary">
    <thead>
      <tr>
        <th class="col text-center">Foto</th>
        <th class="col text-center">NISN</th>
        <th class="col text-center">Nama Siswa</th>
        <th class="col text-center">Jenis Kelamin</th>
        <th class="col text-center">Alamat</th>
        <th class="col text-center">Jurusan</th>
        <th class="col text-center">Kelas</th>
        <th class="col text-center">Ekstrakulikuler</th>
        <th class="col text-center">Guru Pembimbing</th>
        <th class="col text-center">Tempat Lahir</th>
        <th class="col text-center">Tanggal Lahir</th>
        <th class="col text-center">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center ">
              <img src="<?php echo e(url('fotosiswa/'.$item['url_siswa'])); ?>" class="img-fluid" style="max-width:50px;">
            </td>
            <td class="text-center">
              <?php echo e($item['nisn']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['nama']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['jenis_kelamin']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['alamat']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['jurusan']['singkatan']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['kelas']['nama']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['eskul']['nama']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['guru']['nama']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['tempat_lahir']); ?>

            </td>
            <td class="text-center">
              <?php echo e($item['tanggal_lahir']); ?>

            </td>
            <td class="text-center">
              <form action="<?php echo e(route('siswa.destroy', $item["id"])); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-danger show_confirm" data-name="<?php echo e($item['nama']); ?>">Hapus</button>
                <a href="<?php echo e(route('siswa.edit', $item["id"])); ?>" class="btn btn-sm btn-warning col-lg-5">Edit</a>
              </form>
            </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(session('success')): ?>
  <script>
    Swal.fire({
    title: "Good job!",
    text: "<?php echo e(session('success')); ?>",
    icon: "success"
    });
  </script>
<?php endif; ?>
<!-- confirm dialog -->
<script type="text/javascript">
 
  $('.show_confirm').click(function(event) {
       let form =  $(this).closest("form");
       let name = $(this).data("name");
       event.preventDefault();
       Swal.fire({
         title: " Yakin Mau di hapus ? ",
         text: "Data Kamu tidak akan bisa Kembali lagi!",
         icon: "warning",
         showCancelButton: true,
         confirmButtonColor: "#3085d6",
         cancelButtonColor: "#d33",
         confirmButtonText: "Iya, Yakin!"
       })
       .then((willDelete) => {
         if (willDelete.isConfirmed) {
           form.submit();
         }
       });
   });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rpl\project-uas-si4b-supergaek\SekolahApp\resources\views/siswa/index.blade.php ENDPATH**/ ?>