<?php $__env->startSection('title', 'JURUSAN'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-center">JURUSAN</h1>
<a href="<?php echo e(route('jurusan.create')); ?>" class="btn btn-primary col-lg-12 mb-3">Tambah Jurusan</a>
<table class="table table-bordered border-primary">
  <thead>
    <tr>
      <th class="col text-center">Singkatan Jurusan</th>
      <th class="col text-center">Nama Jurusan</th>
      <th class="col text-center">Pimpinan Jurusan</th>
      <th class="col text-center">Deskripsi Jurusan</th>
      <th class="col text-center">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-center">
            <?php echo e($item['singkatan']); ?>

          </td>
          <td class="text-center">
            <?php echo e($item['nama']); ?>

          </td>
          <td class="text-center">
            <?php echo e($item['pimpinan']); ?>

          </td>
          <td class="text-center">
            <?php echo e($item['deskripsi']); ?>

          </td>
          <td class="text-center">
            <form action="<?php echo e(route('jurusan.destroy', $item["id"])); ?>" method="post">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-sm btn-danger show_confirm" data-name="<?php echo e($item['nama']); ?>">Hapus</button>
              <a href="<?php echo e(route('jurusan.edit', $item["id"])); ?>" class="btn btn-sm btn-warning col-lg-5">Edit</a>
            </form>
          </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(session('success')): ?>
  <script>
    Swal.fire({
    title: "Good job!",
    text: "<?php echo e(session('success')); ?>",
    icon: "success"
    });
  </script>
<?php endif; ?>
<!-- confirm dialog -->
<script type="text/javascript">
 
  $('.show_confirm').click(function(event) {
       let form =  $(this).closest("form");
       let name = $(this).data("name");
       event.preventDefault();
       Swal.fire({
         title: " Yakin Mau di hapus? ",
         text: "Data Kamu tidak akan bisa Kembali lagi!",
         icon: "warning",
         showCancelButton: true,
         confirmButtonColor: "#3085d6",
         cancelButtonColor: "#d33",
         confirmButtonText: "Iya, Yakin!"
       })
       .then((willDelete) => {
         if (willDelete.isConfirmed) {
           form.submit();
         }
       });
   });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Downloads\project-uas-si4b-supergaek\SekolahApp\resources\views/jurusan/index.blade.php ENDPATH**/ ?>